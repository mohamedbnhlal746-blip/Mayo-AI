MATYO AI 0.1 PWA

رفع التطبيق:
1) استخرج ملف ZIP.
2) ارفع محتويات مجلد MatyoAI_PWA إلى Netlify Drop (يجب أن يكون index.html في جذر الملفات المرفوعة).
3) افتح رابط Netlify الجديد ثم أدخله في PWABuilder.

يتضمن المشروع manifest.webmanifest وأيقونتي PNG مربعتين 192x192 و512x512 مع purpose=any.
هذه نسخة تجريبية بإجابات محلية محدودة، وليست نموذج ذكاء اصطناعي كامل.
